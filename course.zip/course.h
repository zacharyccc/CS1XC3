/**
 * @file course.h
 * @author Yicheng Zhou (zhouy377@mcmaster.ca)
 * @brief Course type stores a course with field name, code, total students.
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "student.h"
#include <stdbool.h>
 
/**
 * @brief Course type stores a course with field name, code, total students.
 * 
 */
typedef struct _course 
{
  char name[100]; /**< course name */
  char code[10];  /**< course code */
  Student *students;
  int total_students; /**< course total stident */
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


