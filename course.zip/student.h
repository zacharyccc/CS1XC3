/**
 * @file student.h
 * @author Yicheng Zhou (zhouy377@mcmaster.ca)
 * @brief Student type stores a student with field first name, last name, id, grade, number grade.
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/**
 * @brief Student type stores a student with field first name, last name, id, grade, number grade.
 * 
 */
typedef struct _student 
{ 
  char first_name[50];  /**< student first name */
  char last_name[50];   /**< student last name */
  char id[11];  /**< student id */
  double *grades;   /**< student grade */
  int num_grades; /**< student number grade */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
